/*
 * This file is not licensed at all! DO WHATEVER MAN!
 */

using System;

namespace XNBDecompressor
{
	using System.IO;
	
	public class DecompressionTest
	{
		public DecompressionTest ()
		{
		}
		
		public static void Main(string[] args)
		{
			if(args.Length < 2)
			{
				Console.WriteLine("usage: " + args[0] + " in.xnb out.xnb");
				return;
			}
			
			FileStream inFile = new FileStream(args[0], FileMode.Open);
			FileStream outFile = new FileStream(args[1], FileMode.Create);
			
			byte[] buffer = new byte[4];
			inFile.Read(buffer, 0, 3);
			// check our header
			if(buffer[0] != 'X' | buffer[1] != 'N' || buffer[2] != 'B')
			{
				Console.WriteLine("Incorrect Header");
				return;
			}
			
			// get our platform
			inFile.Read(buffer, 0, 1);
			char PLATFORM = (char)buffer[0];
			Console.WriteLine("Platform: " + PLATFORM);
			
			// get our version short
			inFile.Read(buffer, 0, 2);
			ushort version = (ushort)(buffer[1] << 8 | buffer[0]);
			
			int graphicsProfile = version & 0x7f00;
			version &= 0x80ff;
			
			// 0x80 means compressed
			// this decompression program seems to work for either
			// version 4 and 5 XNB files
			bool compressed = false;
			if (version == 0x8005 || version == 0x8004)
				compressed = true;
			else if(version != 5 && version != 4)
			{
				Console.WriteLine("Invalid XNB version");
				return;
			}
			
			// get our compressed file size
			inFile.Read(buffer, 0, 4);
			int fileSize = buffer[3] << 24 | buffer[2] << 16 | buffer[1] << 8 | buffer[0];
			
			if(compressed)
			{
				// file size without the header
				int compressedSize = fileSize - 14;
				// now get the decompressed filesize
				inFile.Read(buffer, 0, 4);
				int decompressedSize = buffer[3] << 24 | buffer[2] << 16 | buffer[1] << 8 | buffer[0];
				
				// write out our header
				outFile.WriteByte((byte)'X'); outFile.WriteByte((byte)'N'); outFile.WriteByte((byte)'B');
				outFile.WriteByte((byte)'w'); outFile.WriteByte(0x05); outFile.WriteByte(0x00);
				
				// write out the final file size, which INCLUDES the 10 byte header
				int newFileSize = decompressedSize + 10;
				buffer[0] = (byte)newFileSize; buffer[1] = (byte)(newFileSize >> 8);
				buffer[2] = (byte)(newFileSize >> 16); buffer[3] = (byte)(newFileSize >> 24);
				outFile.Write(buffer, 0, 4);
				
				// set our window to 16 bits, meaning the window size will be 64Kb
				// which is default for XNB compressed files
				LzxDecoder dec = new LzxDecoder(16);
				int decodedBytes = 0;
				int pos = 0;
				while(pos < compressedSize)
				{
					// let's seek to the correct position
					inFile.Seek(pos+14, SeekOrigin.Begin);
					// get the size of the compressed block
					int hi, lo;
					hi = inFile.ReadByte();
					lo = inFile.ReadByte();
					int block_size = 0;
					block_size = (hi << 8) | lo;
					// all blocks by default will output 32Kb of data, so thus
					// is our frame size
					int frame_size = 0x8000;
					// ... unless this block is special, that it outputs a different
					// amount of data. this blocks header is identified by a 0xFF byte
					if(hi == 0xFF)
					{
						// that means the lo byte was the hi byte
						hi = lo;
						lo = (byte)inFile.ReadByte();
						// ... which combined to a different output/frame size for this
						// particular block
						frame_size = (hi << 8) | lo;
						// now get our block size
						hi = (byte)inFile.ReadByte();
						lo = (byte)inFile.ReadByte();
						block_size = (hi << 8) | lo;
						// advance our read position by the size of this block's header
						pos += 5;
					} else
						// advance our read position by the size of this block's header
						pos += 2;
					
					// if either is zero, that means it's over
					if(block_size == 0 || frame_size == 0)
						break;
					
					// decompress that block!
					int lzxRet = dec.Decompress(inFile, block_size, outFile, frame_size);
					// print stuff
					pos += block_size;
					decodedBytes += frame_size;
				}
			}
		}
	}
}

