#ifndef __COMMON__
#define __COMMON__

enum FileType{
	SINGLE_FILE,
	TEXT_ARCHIVE,
	NO_FILE
};

#endif