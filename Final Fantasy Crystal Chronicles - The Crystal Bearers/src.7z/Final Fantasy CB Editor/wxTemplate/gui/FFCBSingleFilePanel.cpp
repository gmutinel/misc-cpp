#include "FFCBSingleFilePanel.h"

FFCBSingleFilePanel::FFCBSingleFilePanel( wxWindow* parent )
:
SingleFilePanel( parent )
{

}

void FFCBSingleFilePanel::OnApplyChanges( wxCommandEvent& event )
{
	file->GetTextSection()->SetText(textField->GetValue());
	file->SaveTo(fileName);
}

void FFCBSingleFilePanel::SetFile(CBSingleFile* f,wxString& fn)
{
	file=f;
	textField->SetValue(file->GetTextSection()->GetText());
	fileName=fn;
}
