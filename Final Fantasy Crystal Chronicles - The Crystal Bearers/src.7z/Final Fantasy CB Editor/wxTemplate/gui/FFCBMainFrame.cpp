#include "FFCBMainFrame.h"
#include <wx/filedlg.h>
#include <wx/filename.h>
#include <wx/dir.h>

#include "CBItemData.h"
#include "FFCBPreviewDialog.h"

#include "../cblib/CBSingleFile.h"
#include "../cblib/CBTextArchive.h"
#include "../common/DBManager.h"

FFCBMainFrame::FFCBMainFrame( wxWindow* parent )
:
MainFrame( parent )
{
	filesTree->AddRoot(wxT("Opened files"));
	singleFilePanel=new FFCBSingleFilePanel(rightPanel);
	rightPanel->GetSizer()->Add(singleFilePanel, 1, wxALL|wxEXPAND, 5 );
	singleFilePanel->Show(false);

	archivePanel=new FFCBTextArchivePanel(rightPanel);
	rightPanel->GetSizer()->Add(archivePanel, 1, wxALL|wxEXPAND, 5 );
	archivePanel->Show(false);
}


void FFCBMainFrame::OnClickOpen( wxCommandEvent& event )
{
	wxFileDialog dialog(this);
	int res=dialog.ShowModal();

	if(res!=wxID_OK) return;

	wxString fileName=dialog.GetPath();
	
	CheckAndOpenFile(fileName);
}

void FFCBMainFrame::OnClickFolder( wxCommandEvent& event )
{
	wxDirDialog dialog(this);
	int res=dialog.ShowModal();

	if(res!=wxID_OK) return;

	wxArrayString names;
	wxDir::GetAllFiles(dialog.GetPath(),&names,wxEmptyString,wxDIR_FILES);

	for(size_t i=0;i<names.GetCount();i++)
		CheckAndOpenFile(names[i]);
	
}

void FFCBMainFrame::CheckAndOpenFile(wxString& fileName)
{
	wxFileName fn(fileName);
	switch(CheckFileType(fileName)){
		//il file contiene una sola sezione di testo
		case SINGLE_FILE:
		{
			CBSingleFile* file=new CBSingleFile(fileName);
			wxTreeItemId itmId=filesTree->AppendItem(filesTree->GetRootItem(),fn.GetFullName());
			
			CBItemData* parentData=new CBItemData();
			parentData->SetType(CB_SINGLE_FILE);
			parentData->SetString(fileName);
			parentData->SetData(file);

			filesTree->SetItemData(itmId,parentData);

			CBItemData* itmData=new CBItemData();


			itmData->SetType(CB_TEXT_SECTION);
			itmData->SetSectionIndex(0);

			itmId=filesTree->AppendItem(itmId,wxT("Text Section"));
			
			filesTree->SetItemData(itmId,itmData);

		}
		break;

		//il file � un archivio di testi
		case TEXT_ARCHIVE:
		{
			CBTextArchive* file=new CBTextArchive(fileName);

			wxTreeItemId parentId=filesTree->AppendItem(filesTree->GetRootItem(),fn.GetFullName());
			
			CBItemData* parentData=new CBItemData();
			parentData->SetType(CB_TEXT_ARCHIVE);
			parentData->SetString(fileName);
			parentData->SetData(file);

			filesTree->SetItemData(parentId,parentData);

			for(size_t i=0;i<file->Size();i++){
				CBItemData* itmData=new CBItemData();

				itmData->SetType(CB_TEXT_SECTION);
				itmData->SetSectionIndex(i);

				wxTreeItemId curId=filesTree->AppendItem(parentId,wxString::Format(wxT("Text Section %d"),i+1));
			
				filesTree->SetItemData(curId,itmData);
			}
		}
		break;
	}
}


void FFCBMainFrame::OnItemClicked( wxTreeEvent& event )
{
	wxTreeItemId id=event.GetItem();
	if(!filesTree->GetItemData(id))
		return;

	CBItemData* data=(CBItemData*)filesTree->GetItemData(id);

	if(data->GetType()!=CB_TEXT_SECTION)
		return;

	wxTreeItemId parentId=filesTree->GetItemParent(id);
	CBItemData* parentData=(CBItemData*)filesTree->GetItemData(parentId);

	switch(parentData->GetType()){
		case CB_SINGLE_FILE:
		{
			archivePanel->Show(false);
			nullPanel->Show(false);
			wxString name=parentData->GetString(); //filename
			singleFilePanel->SetFile((CBSingleFile*)parentData->GetData(),name);
			singleFilePanel->Show(true);
		}

		break;

		case CB_TEXT_ARCHIVE:
			singleFilePanel->Show(false);
			nullPanel->Show(false);
			wxString name=parentData->GetString(); //filename
			archivePanel->SetEditInfo((CBTextArchive*)parentData->GetData(),data->GetSectionIndex(),name);
			archivePanel->Show(true);

		break;
	}

	rightPanel->Layout();
}


void FFCBMainFrame::OnExit( wxCloseEvent& event )
{
	Destroy();
}

void FFCBMainFrame::OnClickExit( wxCommandEvent& event )
{
	Destroy();
}

void FFCBMainFrame::OnAbout( wxCommandEvent& event )
{
	wxMessageBox(wxT("Final Fantasy Crystal Bearers Text Editor v0.1.\nPhoenix (SadNES cITy Translations)."),
				 wxT("Info"),
				 wxICON_INFORMATION,
				 this);
}
FileType FFCBMainFrame::CheckFileType(wxString& fileName)
{
	FileType type;
	wxFileName fn(fileName);
	DBManager* manager=DBManager::GetInstance();
	if(!manager->Contains(fn.GetFullName())){
		FFCBPreviewDialog dialog(this,fileName);
		type=dialog.GetFileType();
	}else
		return manager->GetFileType(fn.GetFullName());

	return type;
}
