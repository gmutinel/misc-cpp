///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Apr 16 2008)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __cbgui__
#define __cbgui__

#include <wx/string.h>
#include <wx/stattext.h>
#include <wx/gdicmn.h>
#include <wx/font.h>
#include <wx/colour.h>
#include <wx/settings.h>
#include <wx/sizer.h>
#include <wx/panel.h>
#include <wx/textctrl.h>
#include <wx/statbox.h>
#include <wx/button.h>
#include <wx/bitmap.h>
#include <wx/image.h>
#include <wx/icon.h>
#include <wx/menu.h>
#include <wx/treectrl.h>
#include <wx/splitter.h>
#include <wx/frame.h>
#include <wx/choice.h>
#include <wx/dialog.h>

///////////////////////////////////////////////////////////////////////////

#define wxID_PREV_BUTTON 1000
#define wxID_NEXT_BUTTON 1001
#define wxID_SAVE_BUTTON 1002
#define wxID_SAVE_ALL 1003
#define wxID_MENU_OPEN 1004
#define wxID_MENU_FOLDER 1005
#define wxID_FILES_TREE 1006

///////////////////////////////////////////////////////////////////////////////
/// Class NullPanel
///////////////////////////////////////////////////////////////////////////////
class NullPanel : public wxPanel 
{
	private:
	
	protected:
		wxStaticText* m_staticText2;
	
	public:
		NullPanel( wxWindow* parent, wxWindowID id = wxID_ANY, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( -1,-1 ), long style = wxTAB_TRAVERSAL );
		~NullPanel();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class SingleFilePanel
///////////////////////////////////////////////////////////////////////////////
class SingleFilePanel : public wxPanel 
{
	DECLARE_EVENT_TABLE()
	private:
		
		// Private event handlers
		void _wxFB_OnApplyChanges( wxCommandEvent& event ){ OnApplyChanges( event ); }
		
	
	protected:
		wxTextCtrl* textField;
		wxButton* applyButton;
		
		// Virtual event handlers, overide them in your derived class
		virtual void OnApplyChanges( wxCommandEvent& event ){ event.Skip(); }
		
	
	public:
		SingleFilePanel( wxWindow* parent, wxWindowID id = wxID_ANY, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( -1,-1 ), long style = wxTAB_TRAVERSAL );
		~SingleFilePanel();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class TextArchivePanel
///////////////////////////////////////////////////////////////////////////////
class TextArchivePanel : public wxPanel 
{
	DECLARE_EVENT_TABLE()
	private:
		
		// Private event handlers
		void _wxFB_OnPrevText( wxCommandEvent& event ){ OnPrevText( event ); }
		void _wxFB_OnNextText( wxCommandEvent& event ){ OnNextText( event ); }
		void _wxFB_OnApply( wxCommandEvent& event ){ OnApply( event ); }
		void _wxFB_OnSaveAll( wxCommandEvent& event ){ OnSaveAll( event ); }
		
	
	protected:
		wxButton* prevTextButton;
		wxStaticText* staticSectionIdx;
		wxStaticText* staticSep;
		wxStaticText* staticTotal;
		wxButton* nextTextButton;
		wxTextCtrl* textField;
		wxButton* applyButton;
		wxButton* saveAllButton;
		
		// Virtual event handlers, overide them in your derived class
		virtual void OnPrevText( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnNextText( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnApply( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnSaveAll( wxCommandEvent& event ){ event.Skip(); }
		
	
	public:
		TextArchivePanel( wxWindow* parent, wxWindowID id = wxID_ANY, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 418,176 ), long style = wxTAB_TRAVERSAL );
		~TextArchivePanel();
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class MainFrame
///////////////////////////////////////////////////////////////////////////////
class MainFrame : public wxFrame 
{
	DECLARE_EVENT_TABLE()
	private:
		
		// Private event handlers
		void _wxFB_OnExit( wxCloseEvent& event ){ OnExit( event ); }
		void _wxFB_OnClickOpen( wxCommandEvent& event ){ OnClickOpen( event ); }
		void _wxFB_OnClickFolder( wxCommandEvent& event ){ OnClickFolder( event ); }
		void _wxFB_OnClickExit( wxCommandEvent& event ){ OnClickExit( event ); }
		void _wxFB_OnAbout( wxCommandEvent& event ){ OnAbout( event ); }
		void _wxFB_OnItemClicked( wxTreeEvent& event ){ OnItemClicked( event ); }
		
	
	protected:
		wxMenuBar* menuBar;
		wxMenu* fileMenu;
		wxMenu* helpMenu;
		wxSplitterWindow* splitter;
		wxPanel* leftPanel;
		wxTreeCtrl* filesTree;
		wxPanel* rightPanel;
		NullPanel* nullPanel;
		
		// Virtual event handlers, overide them in your derived class
		virtual void OnExit( wxCloseEvent& event ){ event.Skip(); }
		virtual void OnClickOpen( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnClickFolder( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnClickExit( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnAbout( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnItemClicked( wxTreeEvent& event ){ event.Skip(); }
		
	
	public:
		MainFrame( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxT("Final Fantasy Crystal Bearers Editor"), const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 554,337 ), long style = wxDEFAULT_FRAME_STYLE|wxTAB_TRAVERSAL );
		~MainFrame();
		void splitterOnIdle( wxIdleEvent& )
		{
		splitter->SetSashPosition( 144 );
		splitter->Disconnect( wxEVT_IDLE, wxIdleEventHandler( MainFrame::splitterOnIdle ), NULL, this );
		}
		
	
};

///////////////////////////////////////////////////////////////////////////////
/// Class PreviewDialog
///////////////////////////////////////////////////////////////////////////////
class PreviewDialog : public wxDialog 
{
	DECLARE_EVENT_TABLE()
	private:
		
		// Private event handlers
		void _wxFB_OnExit( wxCloseEvent& event ){ OnExit( event ); }
		void _wxFB_OnPreview( wxCommandEvent& event ){ OnPreview( event ); }
		void _wxFB_OnOk( wxCommandEvent& event ){ OnOk( event ); }
		void _wxFB_OnCancel( wxCommandEvent& event ){ OnCancel( event ); }
		
	
	protected:
		wxButton* previewButton;
		wxChoice* choiceBox;
		wxButton* okButton;
		wxButton* cancelButton;
		
		// Virtual event handlers, overide them in your derived class
		virtual void OnExit( wxCloseEvent& event ){ event.Skip(); }
		virtual void OnPreview( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnOk( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnCancel( wxCommandEvent& event ){ event.Skip(); }
		
	
	public:
		PreviewDialog( wxWindow* parent, wxWindowID id = wxID_ANY, const wxString& title = wxEmptyString, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxSize( 450,60 ), long style = wxDEFAULT_DIALOG_STYLE );
		~PreviewDialog();
	
};

#endif //__cbgui__
