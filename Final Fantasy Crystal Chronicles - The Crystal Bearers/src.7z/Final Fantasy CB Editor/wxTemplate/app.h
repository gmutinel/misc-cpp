#include <wx/wx.h>

class App : public wxApp{

public:
	virtual bool OnInit();
};
DECLARE_APP(App);