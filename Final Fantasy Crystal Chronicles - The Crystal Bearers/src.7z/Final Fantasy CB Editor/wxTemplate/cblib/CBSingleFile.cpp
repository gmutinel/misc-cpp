#include "CBSingleFile.h"
#include "CBSingleFileTextSection.h"
#include <wx/wfstream.h>

//costruttore da file, richiama il costruttore da stream
CBSingleFile::CBSingleFile(wxString& fileName)
{
	Initialize(wxFileInputStream(fileName));
}

CBSingleFile::CBSingleFile(const wxChar* fileName)
{
	Initialize(wxFileInputStream(fileName));
}
//costruttore da stream
CBSingleFile::CBSingleFile(wxInputStream& input)
{
	Initialize(input);
}

void CBSingleFile::Initialize(wxInputStream& input)
{
	unknownSection1=NULL;
	unknownSection2=NULL;
	size_t size=input.GetSize();
	wxByte* buffer=new wxByte[size];
	
	input.Read(buffer,size); //leggo il buffer dallo stream (tipo fread)
	
	wxUint32 textPointer=wxINT32_SWAP_ON_LE(((wxUint32*)buffer)[0]); //swappo perch� big endian
	
	textSection=new CBSingleFileTextSection(&buffer[textPointer]); //creo la text section

	wxUint32 secondPointer=wxINT32_SWAP_ON_LE(((wxUint32*)buffer)[1]);
	wxUint32 thirdPointer=wxINT32_SWAP_ON_LE(((wxUint32*)buffer)[2]);

	if(secondPointer!=0){ //� presente la seconda sezione
		wxUint32 sectionSize=0;
		if(thirdPointer!=0){ //se esiste anche l'ultima sezione
			sectionSize=thirdPointer-secondPointer;

			//carico anche la terza sezione
			wxUint32 lastSectionSize=size-thirdPointer;
			unknownSection2=new wxMemoryBuffer(lastSectionSize);
			unknownSection2->AppendData(&buffer[thirdPointer],lastSectionSize);
		}else{ //non c'� la seconda sezione
			sectionSize=size-secondPointer;
		}

		unknownSection1=new wxMemoryBuffer(sectionSize);
		unknownSection1->AppendData(&buffer[secondPointer],sectionSize);
	}

	delete[] buffer;

}
CBSingleFile::~CBSingleFile()
{
	if(textSection)
		delete textSection;
	if(unknownSection1)
		delete unknownSection1;
	if(unknownSection2)
		delete unknownSection2;
}

CBTextSection* CBSingleFile::GetTextSection()
{
	return textSection;
}

int CBSingleFile::SaveTo(wxString& fileName){
	return SaveTo(wxFileOutputStream(fileName));
}

int CBSingleFile::SaveTo(const wxChar* fileName){
	return SaveTo(wxFileOutputStream(fileName));
}

int CBSingleFile::SaveTo(wxOutputStream& output)
{
	wxUint32* header=new wxUint32[HEADER_SIZE/sizeof(wxUint32)];
	wxUint32 len;
	char* buf=textSection->GetWritableBuffer(&len);

	header[0]=HEADER_SIZE;
	if(unknownSection1)
		header[1]=header[0]+GetPaddingSize(len+1)+len+1; //metto len+1 perch� ci star� anche il byte null
	else
		header[1]=0;
	
	if(unknownSection2)
		header[2]=header[1]+unknownSection1->GetDataLen();
	else
		header[2]=0;
	
	header[0]=wxINT32_SWAP_ON_LE(header[0]);
	header[1]=wxINT32_SWAP_ON_LE(header[1]);
	header[2]=wxINT32_SWAP_ON_LE(header[2]);

	output.Write(header,HEADER_SIZE);

	output.Write(buf,len);
	output.PutC(NULL);
	for(wxUint32 i=0;i<GetPaddingSize(len+1);i++)
		output.PutC(NULL);

	if(unknownSection1)
		output.Write(unknownSection1->GetData(),unknownSection1->GetDataLen());
	if(unknownSection2)
		output.Write(unknownSection2->GetData(),unknownSection2->GetDataLen());
	
	textSection->FreeBuffer();
	delete[] header;
	return 0;
}

wxUint32 CBSingleFile::GetPaddingSize(wxUint32 curSize)
{
	//cambiare 0x20 con quello che serve per il padding
	if(curSize%0x20==0)
		return 0;
	
	return (0x20 - curSize%0x20);
}
