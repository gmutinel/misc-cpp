#include "app.h"

#include "gui/FFCBMainFrame.h"

IMPLEMENT_APP(App)
bool App::OnInit(){

	MainFrame* frame=new FFCBMainFrame(NULL);
	frame->Show();
	return true;
}
